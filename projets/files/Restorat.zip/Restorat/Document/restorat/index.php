<!DOCTYPE html>

<?php

?>

<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Resto'rat</title>
  <link rel="stylesheet" href="./styles/accueil.css">
  <link rel="shortcut icon" href="./assets/favicon.ico" type="image/x-icon">
</head>

<body class="fond">
  <nav>
    <img src="./assets/restorat_only.png" alt="Logo" class="logo" />

    <ul class="nav-links">
      <li><a href="#">Accueil</a></li>
      <li><a href="#">Présentation</a></li>
      <li><a href="#">Menu</a></li>
      <li><a href="#">Horaires</a></li>
      <li><a href="#">Contact</a></li>
      <li><a href="#">Réservation</a></li>
    </ul>

    <a href="connexion.php"><button class="login-button">Se connecter</button></a>
  </nav>

  <div class="container">
    <p class="text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Enim eaque voluptates consectetur et sit maxime, voluptas minima cupiditate itaque exercitationem accusantium magni, labore perferendis a ad delectus. Asperiores cumque dolores tenetur quis eos, provident distinctio voluptatibus dolorum alias. Commodi maxime quo suscipit necessitatibus, dicta deleniti, ex voluptatum similique sapiente illum ipsum aspernatur repellendus repellat quaerat sunt tenetur ducimus culpa exercitationem repudiandae? Vitae earum, quo quibusdam alias odio at commodi, reiciendis officia quas recusandae voluptatum adipisci, voluptas cumque doloremque hic. Enim quidem odio vitae amet exercitationem, modi, libero suscipit ab debitis cum, eaque itaque dolorem! Cum, assumenda? Tenetur ipsa qui deserunt?</p>

    <img src="./assets/pancarte.png" alt="Pancarte" class="pancarte">
  </div>
</body>

</html>